function [y,ystd,N]=msd2(x,delays)
% calculate MSD for 2 dimensional (xy) data
% x is a cell array of position data, each entry in x is a separate xy
% trajectory (i.e. x{1}=[x1(1), y1(1); x1(2), y1(2); x1(3), y1(3); ...]; 
%       x{2}=[x2(1), y2(1); x2(2), y2(2); x2(3), y2(3); ...];)
% delays is an array of delays (in units of the index of x)
% delay must be less than the number of points in the trajectory

y=[];
ystd=[];
N=[];

Ndat=numel(x);
K=delays;
for j=1:numel(K),
    k=K(j);
    dispsqk=[];
    for kd=1:Ndat,
        clear xk
        xk=x{kd};
        [mx,nx]=size(xk);
        if mx<nx,
            xk=xk';
            [mx,nx]=size(xk);
        end
        if nx==1,
            xk(:,2) = zeros(size(xk(:,1)));
        end
        if k<(mx-1),
            jmax=mx;
            j0=1:(jmax-k); %indices x(t) 
            j1=(k+1):jmax; %indices x(t + Dt)
            dxsq=(xk(j1,1)-xk(j0,1)).^2 + (xk(j1,2)-xk(j0,2)).^2;
            dispsqk=[dispsqk;dxsq];
        end
    end
    jk=find(isnan(dispsqk)==0);
    N(j)=numel(jk);
    y(j)=sum(dispsqk(jk))/N(j); %MSD
    ystd(j)=std(dispsqk(jk)); 
end


end