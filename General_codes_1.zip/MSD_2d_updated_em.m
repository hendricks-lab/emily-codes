function [deltat, msdpts, sem, log_deltat, log_msdpts, alpha, DiffCoef] = MSD_2d_updated (x, y, DT, k_choose)
% msd - calculates the msd curve for 2-D dissusion 
%   x: vector of x positions
%   y: vector of y positions

% modified from
% http://stackoverflow.com/questions/7489048/calculating-mean-squared-displacement-msd-with-matlab
tau = DT; % s time between trajectory points
data = [x y];
nData = length(x); %# number of data points
numberOfDeltaT = 15; %floor(nData/4); %# for MSD, dt should be up to 1/4 of number of data points

sem = zeros(numberOfDeltaT, 1); 
deltat = zeros(numberOfDeltaT, 1); 
msdpts = zeros(numberOfDeltaT, 1); 
sqdisp = zeros(numberOfDeltaT, 1); 

%# calculate msd for all deltaT's

for dt = 1:numberOfDeltaT; 
   deltaCoords = data(1+dt:end,1:2) - data(1:end-dt,1:2);
   sqdisp = sum(deltaCoords.^2,2); %# dx^2+dy^2+dz^2
   deltat(dt) = dt * tau;
   msdpts(dt) = mean(sqdisp);
   sem(dt) = std(sqdisp) / sqrt(length(msdpts) / dt);
    
end
    
    dp=polyfit(deltat,msdpts,1);
    DiffCoef=dp(1)./4;
    log_deltat_if_complete=log(deltat); %this is if there are actually at least 40 timepoints in the dataset.
    log_msdpts_w_nans=log(msdpts);
    log_msdpts=log_msdpts_w_nans(find(~isnan(log_msdpts_w_nans))); % Emily 20230524 Removing the NaN from data for data with less than the number of timepoints set by number of deltaT
    log_deltat=log_deltat_if_complete(1:numel(log_msdpts)); %Ensuring the number of timepoints matches the number of MSD points.
    p=polyfit(log_deltat,log_msdpts,1);
    alpha=p(1);
    
    %figure(k_choose.*1000), hold on, 
%     figure(11),hold on, 
%     plot(deltat, msdpts,'LineWidth',2);
%     xlabel('Tau')
%     ylabel('MSD')
%     
%     figure(22),hold on
%     plot(log_deltat,log_msdpts,'LineWidth',2);
%     set(gca, 'YScale', 'log')
%     set(gca, 'XScale', 'log')
%     xlabel('log(Tau)')
%     ylabel('ln(MSD)')
end