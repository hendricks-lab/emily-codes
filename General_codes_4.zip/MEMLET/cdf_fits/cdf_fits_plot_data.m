%% CDF fits to the plus vs minus Tau data

addpath('C:\Users\abdul\Desktop\Tau paper');

ctrl_minus_fit=0.006032;
ctrl_plus_fit=0.006628;
tau1_plus_fit=0.00545;
tau1_minus_fit=0.00442;
tau10_plus_fit=0.005488;
tau10_minus_fit=0.00465;

dat=[ctrl_plus_fit,ctrl_minus_fit,tau1_plus_fit,tau1_minus_fit,tau10_plus_fit,tau10_minus_fit];

results=1./dat;

%func=(k1*exp(-k1*t));