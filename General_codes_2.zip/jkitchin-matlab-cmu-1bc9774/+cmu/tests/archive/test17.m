clear all

u = cmu.units;

a = [1 2 3]*u.s;

min(a)

%5*u.s > 3*u.kg
%5*u.s < 3*u.kg