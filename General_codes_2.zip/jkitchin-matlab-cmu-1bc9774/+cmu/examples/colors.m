function c = colors(colorname)
color_database = containers.Map();
